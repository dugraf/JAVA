package main;
import java.io.IOException;
import estoque.Estoque;
import ui.Menu;

public class Program
{
    public static void main(String[] args) throws IOException
    {
        Estoque estoque = new Estoque();
        Menu menu = new Menu();
        menu.menuInicial();
    }
}